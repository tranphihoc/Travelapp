package com.example.virtualtravelapp.model;

public class Introduce {
	private int id;
	private String intro;
	private int id_diadanh;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public int getId_diadanh() {
		return id_diadanh;
	}

	public void setId_diadanh(int id_diadanh) {
		this.id_diadanh = id_diadanh;
	}
}
