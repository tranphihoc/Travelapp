package com.example.virtualtravelapp.model;

public class Vehicle {
	private int id;
	private String name;
	private String detail;
	private String image;
	private int id_diadanh;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getId_diadanh() {
		return id_diadanh;
	}

	public void setId_diadanh(int id_diadanh) {
		this.id_diadanh = id_diadanh;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
